import { Note } from '../entities/note.entity';

export const notesDatabase: Note[] = [{
        "id": "9604c8a9-a880-4cf1-9c43-effa89c4bb8c",
        "name": "Shoping list",
        "created": 1344556800,
        "category": "Task",
        "content": "Tomatos, bread",
        "dates": null,
        "status": "active"
    },
    {
        "id": "d8f8bb44-b020-4724-8de6-b45448f94436",
        "name": "The theory of evolution",
        "created": 1619481600,
        "category": "Random Thought",
        "content": "The evolution",
        "dates": null,
        "status": "active"
    },
    {
        "id": "930ae637-e2fa-48a9-89d5-0fbd4225e693",
        "name": "Books for it",
        "created": 1617235200,
        "category": "Idea",
        "content": "Can be power",
        "dates": null,
        "status": "active"
    },
    {
        "id": "ef4a7b3d-8dff-4a21-9216-742982b1f744",
        "name": "New Feature",
        "created": 1621555200,
        "category": "Idea",
        "content": "Implement new function 3/5/2021, 5/5/2021",
        "dates": "3/5/2021, 5/5/2021",
        "status": "active"
    },
    {
        "id": "4c463aeb-1d98-471a-86f3-1dd07e19635e",
        "name": "William Gaddis",
        "created": 1620345600,
        "category": "Random Thought",
        "content": "Power doesn’t corrupt people; people corrupt power.",
        "dates": null,
        "status": "archived"
    },
    {
        "id": "7cbf32c5-cbfa-4deb-9917-a1663d43d42e",
        "name": "Eric Ries",
        "created": 1621036800,
        "category": "Task",
        "content": "The lean startup.",
        "dates": null,
        "status": "archived"
    },
    {
        "id": "5f179906-2f51-419a-87a4-59ef77dae0d5",
        "name": "Shoping list",
        "created": 1618876800,
        "category": "Task",
        "content": "Tomatos, bread",
        "dates": null,
        "status": "active"
}];
