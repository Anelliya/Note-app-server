import { Category } from './note.entity';


export class Stats {
    category: Category;
    active: number;
    archived: number;
}
